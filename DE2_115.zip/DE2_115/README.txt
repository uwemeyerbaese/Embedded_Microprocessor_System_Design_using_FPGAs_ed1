The DE1_SoC -> DE2_115 conversion was done as follows:

1) To update the PIN file use the TerASIC system builder for *.qsf and *.sdc.
    Replace all PIN and type data in the *.qsf file.
    For HDL files have the 4 ports Clock=clk, SW=in_port, LEDR=Out_port, and Key[0]=reset,
    need to be renames. Watch out: the Qsf data are case sensitive, even if VHDL is not !

For the Nios design required addition modifaction are:

2) For Nios rename all files starting with DE1_SoC to DE2_115;
   same applies for any instances within the file
3) For Qsys make the following changes:
    SDRAM data size from 16 -> 32
    keep base for SW, LEDR, Timer, Key; generate new address space for processor, memory and UART
4) In the VHDL top level design:
    * 2-3 times SDRAM data size from 16-> 32
    * DRAM_DQM is now 4 bit vector

For the Nios C-code the following global constants in address_map_nios2.h need to be be replaced

DE1_SoC                    vs.        DE2_115
=====================================
LEDR_BASE               by  RED_LED_BASE
HEX5_HEX4_BASE   by  HEX7_HEX4_BASE 
FPGA_CHAR_BASE  by  ONCHIP_SRAM_BASE 