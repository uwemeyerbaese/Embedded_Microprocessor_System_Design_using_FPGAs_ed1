These project files for the ZedBoard were adapted from the ZyBo by doing the following:

Under Project Settings replace Project Device: ZyBo by ZedBoard

Under Constraints replace the XDC pin file from ZyBo with the XDC file for the ZedBoard.
Modify and enable (i.e., remove #) pin name to match the HDL:

GCLK -> clk or sys_clk (if a clock diver is used)
BTNC -> reset
LD.. -> out_port[..]
SW.. -> in_port[..]

The reset behavior was also improved that allows the asynchronous reset deactivated in the second clock phase.
A few ROM files (trisc2, trisc3mb, trisc3n) were modified to the VHDL files

  IF reset = '0' THEN              -- Asynchronous preset
    pmd <= prom(0);      -- Improved delay reset behavior        
  ELSIF rising_edge(clk) THEN
...

some Verilog ROMs (trisc3mb, trisc3nios) worked best without a reset at all

  always @ (posedge clk)
      q <= rom[address];
....