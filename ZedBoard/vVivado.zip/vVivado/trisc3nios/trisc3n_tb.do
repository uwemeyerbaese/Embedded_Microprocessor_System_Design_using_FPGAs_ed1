## add a local signal for behavior simulation only
proc add_local {var_name} { 
  if { [catch {add wave $var_name}] > 0 } {
    puts "** Uwe Info: Local Signal $var_name is NOT available!"
  } else {
    puts "** Uwe Info: Add local variable $var_name in wave window for simulation!"
  }
}

## add one of two local signals for behavior simulation only
proc add_one {var_one var_two} { 
  if { [catch {add wave $var_one}] > 0 } {
    puts "** Uwe Info: Local Signal $var_one is NOT available!"
    if { [catch {add wave $var_two}] > 0 } {
      puts "** Uwe Info: Local Signal $var_two is NOT available!"
  } else {    puts "** Uwe Info: Add local variable $var_two in wave window for simulation!"
  }
  } else {
    puts "** Uwe Info: Add local variable $var_one in wave window for simulation!"
  }
}

########## Compile design
puts "** Functional Simulation"
vlib work
vlog data_ram.v
vlog rom4096x32.v
vlog trisc3n.v
vlog trisc3n_tb.v
vsim work.trisc3n_tb

########## Add I/O signals to wave window
#add wave -divider  "Simulation by UMB"
add wave clk
add wave reset
radix -hex
add wave -divider  "Locals:" 
add_local UUT/pc
add_local UUT/op
add_local UUT/opx
add_local UUT/branch_target
add_local UUT/imm16
add_local UUT/imm32
add_local UUT/jc 
add_local UUT/A
add_local UUT/B
add_local UUT/C
add_local UUT/rA
add_local UUT/rB
add_local UUT/rC
add_local UUT/kflag
add_local {UUT/r[1]}
add_local {UUT/r[2]}
add_local {UUT/r[3]}
add_local {UUT/r[4]}
add_local UUT/kflag
add_local UUT/res

add wave -divider  "I/O Ports:"
add wave UUT/in_port 
add wave UUT/out_port

######### Add stimuli data in HDL code => see HDL code
#force clk 0 0ns, 1 10ns -r 20ns
#force reset 1 0ns, 0 5ns
#force iport 3 0ns

########## Run the simulation
run 500ns
wave zoomfull
configure wave -gridperiod 40ns
configure wave -timelineunits ns
