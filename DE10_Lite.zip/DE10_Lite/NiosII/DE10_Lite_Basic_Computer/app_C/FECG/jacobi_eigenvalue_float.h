#ifndef JACOBI_EIGENVALUE_FLOAT_H
#define JACOBI_EIGENVALUE_FLOAT_H

void jacobi_eigenvalue_float ( int n, float a[], int it_max, float v[], float d[], int *it_num, int *rot_num );
void r8mat_diag_get_vector_float ( int n, float a[], float v[] );
void r8mat_identity_float ( int n, float a[] );
float r8mat_is_eigen_right_float ( int n, int k, float a[], float x[],
  float lambda[] );
float r8mat_norm_fro_float ( int m, int n, float a[] );
void r8mat_print_float ( int m, int n, float a[], char *title );
void r8mat_print_some_float ( int m, int n, float a[], int ilo, int jlo, int ihi,
  int jhi, char *title );
void r8vec_print_float ( int n, float a[], char *title );
void timestamp_float ( void );
float *vector(int nl,int nh);
float **matrix(int nrl,int nrh,int ncl,int nch);
void jacobi(float **a,int n,float d[],float **v,int *niter, int *nrot);
float pythag(float a, float b);
void tqli(float d[], float e[], int n, float **z);
void tred2(float **a, int n, float d[], float e[]);

#endif
