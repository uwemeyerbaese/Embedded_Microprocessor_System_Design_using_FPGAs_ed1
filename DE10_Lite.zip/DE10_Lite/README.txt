The DE1_SoC -> DE2_115 conversion was done as follows:

1) To update the PIN file use the TerASIC system builder program to generate *.qsf and *.sdc.
    Replace all PIN and types in the *.qsf file.
    For HDL files have the 4 ports Clock=clk, SW=in_port, LEDR=Out_port, and Key[0]=reset,
    need to be renamed. Watch out: the Qsf data are case sensitive, even if VHDL is not ! 
   Verify in Quartus Pin Planner after full compile.
    MAX10 families do not compile for true dual clock/port RAM with initial values; we therefore for trisc3a
    split in RAM and ROM blocks.

Note that Q15 does not have a DE10_Lite computer; you will need a newer version such as 18.0.
If you upgarde the Basic_Computer often the IP update does not work without problems and you better
copy the DE10_Lite_Computer and rename it DE10_Lite_Basic_Computer
open "Platform Designer" and then remove all component but keep:
System_PLL, Nios2, SDRAM, JTAG_UART, Slider_switches, LEDs, PushButtons, Interval_Timer.
Make sure the timer uses 1ms interval and the JTAG interrupt is set to 5, see Fig. 9.13 in the book.
Update the Verilog source code file, i.e., remove the unused ports. Make sure the SDRAM has 64MB x16 organization.

When using the Q18 monitor the -lm flag for sqrt, sqrtf, etc is NOT added! 
A work-around is to edit the Makefile (before running Action->Compile and Load)
Add the -lm in the Makefile:

niosII_jtag_uart.elf: $(OBJS)
	$(RM) $@ 
	$(CC) $(LDFLAGS) $(OBJS) -lm -o $@ 

Alternative if you do not like to modify the makefile you can also use the BSP source file configuration. This
Makefile add also the FP library to your nios elf and srec file. Compile time will be a little longer initially
generating the BSP.

For the Nios C-code the following global constants in address_map_nios2.h need to be used

DE10_Lite            address
===============================
LEDR_BASE           0xFF200000
HEX3_HEX0_BASE      0xFF200020
HEX5_HEX4_BASE      0xFF200030
KEY_BASE            0xFF200050
SW_BASE	            0xFF200040
TIMER_BASE          0xFF202000
FPGA_PIXEL_BUF_BASE 0x08000000
FPGA_CHAR_BASE      0x09000000

The TopDown design now has original 160x120 16-bit color coding; 
To change this to 320x240 8-bit gray the following was done:
1) In Computer System additional 11 M9K are needed to host the gray image in consecutive coding. Therefore modify
   On_Chip_SRAM  -> 76800 Bytes
2) In the VGA Subsystem the folowing updates are needed:
                               OLD VALUE                NEW VALUE
  VGA Pixel DMA: Addressing:     X-Y                   consecutive
                 Frame           160                    320
                                 120                    240
                 Bits             16                      8
  Pixel FIFO     Color Bits       16                      8
  RGB Resampler                  16-bit RGB          8-bit Grayscale
  Scaler          Width           4                      2
                  Height          4                      2
                  Pixel W        160                     320
                  Pixel H        120                     240

no change: Char buffer Subsystem, Alpha blender, VGA clock, Clock FiFo, VGA controller

  