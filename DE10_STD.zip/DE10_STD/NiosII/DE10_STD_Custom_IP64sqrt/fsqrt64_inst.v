fsqrt64	fsqrt64_inst (
	.clock ( clock_sig ),
	.data ( data_sig ),
	.result ( result_sig )
	);
