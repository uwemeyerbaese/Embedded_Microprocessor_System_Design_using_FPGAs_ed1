The DE1_SoC -> DE10_Nano conversion was done as follows:

1) Quartus and vQuartus 10 RISC machines:
To update the PIN file use the TerASIC system builder for *.qsf and *.sdc.
Replace all PIN and type data in the *.qsf file.
For HDL files have the 4 ports FPGA_CLK1_50=clk, SW=in_port, LED=out_port, and Key[0]=reset,
need to be renamed. Watch out: the QSF data are case sensitive, even if VHDL is not !
Verify in Quartus Pin Planner after full compile.

2) Design the Basic_Computer:
Note that Q15.1 does not has a DE10_Nano computer; you will need a newer version such as 18.0.
The DE10-Nano_Computer provided by the AUP has 2 Nios, ARM, many cmponents and 
very sophisticated memory bridges to allows component access from all processors and should
not be used to build a Basic_Computer. To build a Nios Basic_Computer try first the "IP update" 
of the DE1 SoC basic computer from CD.
If it does not work without problems and if you can not use the top down approach
you should start from zero and go thorught Altera's "Intruduction to the Qsys tool" tutorial to build the system
Open "Platform Designer" and then use components:
DE clock, Nios2, On-chip RAM, JTAG_UART, Slider_switches, LEDs, PushButtons, and Interval_Timer.
The DE10Nano has no SDRAM ->Use Unchip RAM at 50% i.e. 353920 Bytes/357 M10Ks.
Most of our applications are <100KB so this works fine for our applications.
Make sure the timer uses 1ms interval and the JTAG interrupt is set to 5, see Fig. 9.13 in the book.

3) Compile with Altera Monitor program:
When using the Q18 monitor the -lm flag for sqrt, sqrtf, etc is NOT added! 
A work-around is to edit the Makefile (before running Action->Compile and Load)
To add the -lm in the Makefile:

niosII_jtag_uart.elf: $(OBJS)
	$(RM) $@ 
	$(CC) $(LDFLAGS) $(OBJS) -lm -o $@ 

Alternative if you do not like to modify the makefile you can also use the BSP source file configuration. This
Makefile add also the FP library to your nios elf and srec file. Compile time will be a little longer initially
generating the BSP.

For the Nios C-code the following global constants in address_map_nios2.h and address_map_arm.h need to be used

DE10_Nano           address
===============================
LED_BASE    0xFF200000
SW_BASE      0xFF200040
KEY_BASE     0xFF200050
TIMER_BASE   0xFF202000
FPGA_PIXEL_BUF_BASE 0xC8000000
FPGA_CHAR_BASE      0xC9000000

Note the the DE10_Nano has NO HEX display so all program part related to 7-segments must be disabled.

4) Design the ARM/Nios grey VGA TopDown design:
The TopDown design on DE10_Nao has original 320x240 8-bit color coding that is used in app_C example FRACTAL_COLOR 
and MOVIE_COLOR. See the DE10_NanoColorsQ75.jpg for color display on HDMI monitor. Looks more as 6-bit than 8-bit color :(
To run the grey eaxmples in app_C called CLOCK, FRACTAL_GREY and MOVIE_GREY
we change to 640x320 8-bit gray and the following was done:
a) In Computer System additional 64 M10K are needed to host the gray image in consecutive coding. 
  Since the original DE10_Nano already uses 8bit (and not 16 as DE1-SoC) data substantial more memory is needed to 
  host the image with 4 times the pixels. Therefore modify  On_Chip_SRAM  262144 Bytes to 314572 Bytes.
b) In the VGA Subsystem the folowing updates are needed:
                               OLD VALUE                NEW VALUE
  VGA Pixel DMA: Addressing:     X-Y                   consecutive
                 Frame           320                    640
                                 240                    480
                 Bits             8                      8
  RGB Resampler                  8-bit RGB          8-bit Grayscale

remove the scaler and update the connection as in Fig. 9.5 of the book.
no change: Char buffer Subsystem, Alpha blender, VGA clock, Clock FiFo, VGA controller.

c) Program for Nios TopDown design on DE10_Nano:
The ARM and Nios TopDown have the same SOF and SOPCINFO files.
Note that the Nios only has 32KB program memory available. To increase it we will require a complete redesign of the memory map.  
We try to avoid print/scan (see book section 5.7) and  sin/cos computations in CLOCK using a precomputed tables.
If we had the need for display (e.g. nios app_C/MOVIE_GREY)  we used the VGA_text instead.
The 1GB ARM memory can be used by Nios as dynamic memory when using the DE10Nano preloader.
We can store the video in a dynamic allocated array but not a static, so use malloc for array allocation whenever possible.


